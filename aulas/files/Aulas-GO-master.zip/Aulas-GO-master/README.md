# Aulas-GO
Repositório com os exemplos mostrados nas aulas de Golang do canal.
