package main

import (
	"Aulas-GO/a13/message"
	"Aulas-GO/a13/message/say"
)

func main() {
	say.Hello("Eliseu")
	message.Show("eae")
}
