package say

import "Aulas-GO/a13/message"

func Hello(name string) {
	message.Show("Olá, " + name)
}
