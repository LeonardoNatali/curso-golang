package message

import (
	"fmt"
)

func Show(msg string) {
	fmt.Println(msg)
}
